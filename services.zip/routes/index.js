const quotesRoute = require('./quotesRoute.js')


module.exports = {
   quotesRoute
}